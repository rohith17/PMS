package com.flp.pms.service;

import java.util.List;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;

public interface IProductService
{
	public List<Category> chooseCategory();
	
	public List<SubCategory> choose_SUBCategory();
	
	public List<Discount> discountForProduct();
	
	public List<Supplier> supplierForProduct();
	
	public void insertionOfProduct(Product product);
	
	public boolean  modifyProduct(int productId);
	
	public Product modifyingProductFromDatabase(int productId);
	
	
	public void insertionIntoDataBaseAfterUpdate(int prod_Id,Product updproduct);
	
	public boolean deleteProductFromDataBase(int prod_Id);
	
	public boolean nameUpdate(String updateName,int prod_Id);
	
	public boolean productDescriptionUpdate(String descUpdate,int prodId);
	
	public boolean productSupplierIDUpdate(int supplrIdUpdate,int prodId);
	
	public boolean productQuantityUpdateUpdate(int productQuan,int prod_Id);
	
	public boolean productRatingUpdate(Float rating,int prod_id);
	
	public  List<Product> viewFromDatabase();
	 
	public List<Product> searchProductByName(String nameSearch);
	 
	public Product searchProductByRating(Float searchRating);
	
	public Product searchByProducerName(String nameProducer);
	
	public Product searchByCategory(String nameProducer);
	
	public Product searchBySubCategory(String subcategoryName);
	
	public boolean productUpdateAll(String prodName,String prodDesc,int prodSupp,int prodQuan, Float rating,int prod_id);
	
	 public void gsonText(String gsonValue);

	 public String gsonTextResult();
}
