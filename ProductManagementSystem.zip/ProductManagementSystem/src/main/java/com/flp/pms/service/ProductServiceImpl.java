package com.flp.pms.service;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.dao.ProductDaoImplForMap;
import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;

public class ProductServiceImpl implements IProductService
{
	IProductDao iproductdao=new ProductDaoImplForMap();
	
	public List<Category> chooseCategory()
	{
		return iproductdao.chooseCategory();
	}
	
	public List<SubCategory> choose_SUBCategory()
	{
		return iproductdao.choose_SUBCategory();
	}
	
	
	public List<Discount> discountForProduct()
	{
		return iproductdao.discountForProduct();
	}


	
	
	public List<Supplier> supplierForProduct()
	{
		return iproductdao.supplierForProduct();
	}

	public void insertionOfProduct(Product product)
	{
		//int random_Numbers=randomNumbersGeneration();
		
		//product.setProduct_ID(random_Numbers);
		
		iproductdao.insertionOfProduct(product);
		
		
	}

    /*  public int randomNumbersGeneration()
    {
	  int rdm=(int) ((Math.random())*10000);
    return rdm; 
    }*/

      public boolean modifyProduct(int productId)
      {
      
    	  boolean checkprodFlag=false;
    	  
     HashMap<Integer,Product> sendProduct=iproductdao.sendingMaptoServiceProduct();
     
     Set<Integer> pdID=sendProduct.keySet();
     
    Iterator it= pdID.iterator();
     
     while(it.hasNext())
     {
    	
    	 if(productId==(Integer)it.next())
    	 {
    		 Product pd=(Product)sendProduct.get(it.next());
    		 
    		 
    	 }
    	 
      }
     
	return false;
     
    }


      public Product modifyingProductFromDatabase(int productId)
      {
    	  
    	 //System.out.println("productId in service"+productId);
    	  
    	int idCount=0; 
    	
    	Product product=null;
    	
    	int[] prodId=iproductdao.dataBaseLogicForComparisionId();
    	
    	for(int i=0;i<prodId.length;i++)
    	{    	
    	if(prodId[i]==productId)   
    	 {
    		idCount++;
    	 }
    	}
    	if(idCount==0)
    	{
    		System.out.println(" Invalid Id Does not exists in DataBase ");
    	}
    	 
    	else
    	{
    		
         product= iproductdao.modifyingProductFromDatabase(productId);
    	}
    	
    	
    	return product;
      }
  	
      public void insertionIntoDataBaseAfterUpdate(int prod_Id,Product updproduct)
      {   	  
    	  iproductdao.insertionIntoDataBaseAfterUpdate(prod_Id,updproduct);
    	  
      }


      public boolean deleteProductFromDataBase(int prod_Id)
      {   	  
    	  boolean deleteProd=iproductdao.deleteProductFromDataBase(prod_Id);
    	  
    	  return deleteProd;
      }

      
      
      public boolean nameUpdate(String nameUpdate,int prodId)
      {
    	 boolean updatedname= iproductdao.nameUpdate(nameUpdate,prodId); 
    	  
    	  return updatedname;
      }



      public boolean productDescriptionUpdate(String nameUpdate,int prodId)
      {
    	 boolean updateddesc= iproductdao.productDescriptionUpdate(nameUpdate,prodId); 
    	  
    	  return updateddesc;
      }


      public boolean productSupplierIDUpdate(int supplrIdUpdate,int prodId)
      {
                boolean updatedsupp= iproductdao.productSupplierIDUpdate(supplrIdUpdate,prodId); 
    	  
    	  return updatedsupp;
    	  
      }


      public boolean productQuantityUpdateUpdate(int productQuan,int prod_Id)
      {
                boolean updatedQuan= iproductdao.productQuantityUpdateUpdate(productQuan,prod_Id); 
    	  
    	  return updatedQuan;
    	  
      }

      public boolean productRatingUpdate(Float rating,int prod_id)
      {
           boolean updatedRating= iproductdao.productRatingUpdate(rating,prod_id); 
    	  
    	  return updatedRating;
      }
      
      public  List<Product> viewFromDatabase()
      {
    	  return iproductdao.viewFromDatabase();
      }

  
      
      public List<Product> searchProductByName(String nameSearch)
      {
    	 return   iproductdao.searchProductByName(nameSearch);  
      }
      
      
      public Product searchProductByRating(Float searchRating)
      {
    	  
    	  System.out.println(" I am in service Impl  nameSearch name is :"+searchRating);
    		return   iproductdao.searchProductByRating(searchRating);  
    		
      }
      
      public Product searchByProducerName(String nameProducer)
      {
    	  return   iproductdao.searchByProducerName(nameProducer); 
    	  
      }
      
      public Product searchByCategory(String categoryName)
      {
    	   return   iproductdao.searchByCategory(categoryName); 
      }
      
     
      
      public Product searchBySubCategory(String subcategoryName)
      {
    	   return   iproductdao.searchBySubCategory(subcategoryName); 
      }
      
      public boolean productUpdateAll(String prodName,String prodDesc,int prodSupp,int prodQuan, Float rating,int prod_id)
      {
    	  return   iproductdao.productUpdateAll(prodName,prodDesc,prodSupp,prodQuan,rating,prod_id);   
      }
      
      public void gsonText(String gsonValue)
      {
    	  iproductdao.gsonText(gsonValue);
    	  
      }
      
      public String gsonTextResult()
      {
     	return  iproductdao.gsonTextResult(); 
      }
      
}
