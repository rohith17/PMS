package com.flp.pms.util;

import java.util.Date;

public class Validate
{

	public static boolean validateProductName(String productname)
	{
		return productname.matches("[A-Z][a-z_$0-9 ]*");
	}
	
	public static boolean validateDate(String manufacturingdate)
	{
		return manufacturingdate.matches("[0-3][1-9]-(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)-[1-9][0256789][0-9][0-9]");
	}
	
	public static boolean validateExpiry(String expirydate)
	{
		Date date=new Date(expirydate);
		return date.after(new Date());
	}
	
	public static boolean validateOptions(int []id)
	{
		for(int i=0;i<id.length;i++)
		{
			
		}
		
		return false;
		
	}
	
	
	public static boolean validateRatings(float rating)
	{
		if(rating>5.0 | rating<1.0)
		{
			System.out.println("  Invalid ! Ratings. Please Rate in between 1 to 5.  ");
			return false;
		}
		
		else
		return true;
	}
	
}
