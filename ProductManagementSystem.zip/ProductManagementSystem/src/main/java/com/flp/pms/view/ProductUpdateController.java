package com.flp.pms.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;
import com.google.gson.Gson;


public class ProductUpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		System.out.println(" hello Product update ");
		
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		Product prodModify=null;
		
		String productId=request.getParameter("productId");
		System.out.println("productId"+productId);
		
		IProductService serviceImpl=new ProductServiceImpl();
		
		
		prodModify=serviceImpl.modifyingProductFromDatabase(Integer.parseInt(productId));
		
		System.out.println(" hello "+prodModify.getManufacturing_Date());
		
		System.out.println(prodModify.getProduct_category().getCategory_ID());
		
		//Category List
		
		String catgoryName=null;
		List<Category> categoryUpdate=serviceImpl.chooseCategory();
		
		for(Category catgListUpdate:categoryUpdate)
		{
			if(prodModify.getProduct_category().getCategory_ID()==catgListUpdate.getCategory_ID())
			{
				System.out.println("Category List : "+catgListUpdate.getCategory_Name());
				catgoryName=catgListUpdate.getCategory_Name();
			}
			
		}
		
		String subCategoryName=null;
		//Sub-Category 
		List<SubCategory> subcategoryUpdate=serviceImpl.choose_SUBCategory();
		
		for(SubCategory subcatgListUpdate:subcategoryUpdate)
		{
			if(prodModify.getProduct_Subcategory().getSub_category_ID()==subcatgListUpdate.getSub_category_ID())
			{
				System.out.println("Sub-Category List : "+subcatgListUpdate.getSub_category_Name());
				subCategoryName=subcatgListUpdate.getSub_category_Name();
			}
			
		}
		
		
		String supplierName=null;
		//Supplier List
        List<Supplier> supplierUpdate=serviceImpl.supplierForProduct();
		
		for(Supplier supplierListUpdate:supplierUpdate)
		{
			if(prodModify.getProduct_Supplier().getSupplier_ID()==supplierListUpdate.getSupplier_ID())
			{
				System.out.println("Sub-Category List : "+supplierListUpdate.getSupplier_firstName());
				supplierName=supplierListUpdate.getSupplier_firstName();
			}
			
		}
		
		
		System.out.println("Prod description :"+prodModify.getProduct_Description());
		
		prodModify.getProduct_Name();
		
		System.out.println("My product Id is :"+productId);
		
		out.println("<html>");
		out.println("<body>");
		out.println("<div>");
		out.println("<table>");
		out.println("<form action='ProductUpdateSaveServlet' method='post'>");
		out.println("<tr>");
		out.println("<td>Name of Product is :</td>");
		out.println("<td><input type='text' name='prod_Name' value='"+prodModify.getProduct_Name()+"'></td></tr>");
		out.println("<tr><td>Description of Product is :</td>");
		out.println("<td><textarea name='prod_Description' rows='5' cols='20'>"+prodModify.getProduct_Description()+"</textarea></td></tr>");
		out.println("<tr><td>Manufacturing Date of Product is :</td>");
		out.println("<td>"+prodModify.getManufacturing_Date()+"</td></tr>");
		out.println("<tr><td>Expiry Date of Product is :</td>");
		out.println("<td>"+prodModify.getExpiry_Date()+"</td></tr>");
		out.println("<tr><td> Maximum Retail Price :</td>");
		out.println("<td>"+prodModify.getProduct_maximum_RetailPrice()+"</td></tr>");
		out.println("<tr><td> Product Category Name :</td>");
		out.println("<td>"+catgoryName+"</td></tr>");
		out.println("<tr><td> Product Sub-Category Name :</td>");
		out.println("<td>"+subCategoryName+"</td></tr>");	
		out.println("<tr><td> Product Supplier Name :</td>");
		out.println("<td><input type='text' value='"+supplierName+"' name='prod_Supplr'></td></tr>");
		out.println("<tr><td> Product Quantity :</td>");
		out.println("<td><input type='text' value='"+prodModify.getProduct_Quantity()+"' name='prod_Quant' ></td></tr>");		
		out.println("<tr><td> Product Rating :</td>");
		out.println("<td><input type='text' value='"+prodModify.getProduct_Rating()+"' name='prod_rating' ></td></tr>");
		out.println("<tr><td><input type='submit' value='update'></td></tr>");
		out.println(" <input type='hidden' name='prod_ID' value="+productId+">");
		out.println("</form>");
		out.println("</table>");
		out.println("<div>");
		
		
		out.println("List you can Update ");
		out.println("<html>");
		
		out.println("<html>");
		
		out.println("<body>");
		out.println("<html>");
		
		
	  /*  Gson dobj=new Gson();
		
	    String jsonObj=dobj.toJson(prodModify);
		
		out.println(jsonObj);*/
		
		
	}

}
