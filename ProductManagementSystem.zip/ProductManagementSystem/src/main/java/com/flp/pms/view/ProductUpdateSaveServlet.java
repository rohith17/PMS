package com.flp.pms.view;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.domain.Supplier;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;

/**
 * Servlet implementation class ProductUpdateSaveServlet
 */
public class ProductUpdateSaveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		IProductService serviceImpl=new ProductServiceImpl();
		
		System.out.println(" Hello in save Update ");
		String pUpdateId=request.getParameter("prod_ID");
		String prod_Name=request.getParameter("prod_Name");
		String prod_Description=request.getParameter("prod_Description");		
		String prod_Supplr=request.getParameter("prod_Supplr");
		String prod_Quant=request.getParameter("prod_Quant");
		String prod_rating=request.getParameter("prod_rating");
		
		List<Supplier> supplierUpdate=serviceImpl.supplierForProduct();
		
		int suppUpdateId=0;
		
		for(Supplier suppList:supplierUpdate)
		{
			
			
			System.out.println(suppList.getSupplier_firstName());
			
			if(suppList.getSupplier_firstName().equalsIgnoreCase(prod_Supplr))
			{
				suppUpdateId=suppList.getSupplier_ID();
			}
			
		}
		
        System.out.println(" Product Id is :"+pUpdateId);
	    
	    System.out.println(prod_Name+" "+prod_Description+" "+prod_Supplr+" "+prod_Quant
	    		+" "+prod_rating);
		
		
		int prodQuan=Integer.parseInt(prod_Quant);
		Float prodRating=Float.parseFloat(prod_rating);
		int prod_Update=Integer.parseInt(pUpdateId);
		boolean statusUpdate=serviceImpl.productUpdateAll(prod_Name, prod_Description, suppUpdateId, prodQuan, prodRating,prod_Update);
		
		System.out.println(" Successful :"+statusUpdate);
		
	    
	    
	    
	    
	    
		
		
	}

}
