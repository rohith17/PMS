package com.flp.pms.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.domain.Product;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.ProductServiceImpl;
import com.google.gson.Gson;



public class SearchProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		System.out.println(" Hello Search ");
		
		PrintWriter out=response.getWriter();
		
		String searchValue=request.getParameter("search");
		
		String search=request.getParameter("searchCriteria");
		
		//System.out.println("My name is "+search);
		
		//System.out.println(" Search Criteria "+search);
		
		IProductService serviceImpl=new ProductServiceImpl();
		
		
		if(search.equals("name"))
		{
			List<Product> listProduct=serviceImpl.searchProductByName(searchValue);
			
		for(Product productList:listProduct)
		{
			System.out.println(" Product Quantity : "+productList.getProduct_Quantity());
			
		}
			//System.out.println();
			
			System.out.println("Hello sarath");
			
			List<Product> searchList=serviceImpl.searchProductByName(searchValue);
			
		    Gson dobj=new Gson();
			
			String jsonObj=dobj.toJson(searchList);
			
			out.println(jsonObj);
			
			serviceImpl.gsonText(jsonObj);
			
			
			
			response.sendRedirect("pages/resultSearch.html");
			
			
			
			
		}
		else if(search.equals("rating"))
		{
			
		}
		else if(search.equals("producer"))
		{
			
		}
		else if(search.equals("category"))
		{
			
		}
		
		else if(search.equals("subCategory"))
		{
			
		}
		
		
		
	}

}
